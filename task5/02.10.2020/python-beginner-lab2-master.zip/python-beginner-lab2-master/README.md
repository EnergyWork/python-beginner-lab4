# python-beginner-lab2
 ПМИм-1. Лабораторая работа 2.
