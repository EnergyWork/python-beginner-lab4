# python-beginner-lab1
ПМИм-1. Программирование на Python. Лабораторная работа 1.
