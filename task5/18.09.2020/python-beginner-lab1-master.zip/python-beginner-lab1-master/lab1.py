from task1 import *
from task2 import *
from task3 import *
from task4 import *
from task5 import *
from task6 import *
from task7 import *
from task8 import *

if __name__ == "__main__":
    task1(method=5) # (1-5)Пять способов поменять значения переменных местами
    # task2() # Определить четверть
    # task3() # Найти значение функции
    # task4() # Сумма цифр трехзначного числа
    # task5() # Найти корни квадратного уравнени
    # task6() # Числа Фибоначчи
    # task7() # Все перестановки трехзначного числа
    # task8() # Все трехзначные числа Армстронга
