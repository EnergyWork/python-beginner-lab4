def task4():
    """
        #4 Сумма цифр трехзначного числа
    """
    n = input()
    print(sum([int(x) for x in n]))

if __name__ == "__main__":
    task4() # Сумма цифр трехзначного числа